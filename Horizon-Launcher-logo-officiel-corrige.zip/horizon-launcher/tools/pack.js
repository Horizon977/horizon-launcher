#!/usr/bin/env node
'use strict';
/**
 * Outil pour gérer le pack (pack/pack.json) sans le modifier à la main.
 *
 *   node tools/pack.js list
 *   node tools/pack.js set-minecraft 26.3
 *   node tools/pack.js set-loader fabric [version]     (sans version : dernière version stable de Fabric)
 *   node tools/pack.js set-loader vanilla
 *   node tools/pack.js add sodium                      (cherche le mod sur Modrinth pour la bonne version)
 *   node tools/pack.js remove sodium
 *   node tools/pack.js bump                            (1.0.0 -> 1.0.1 : à faire à chaque changement du pack)
 */
const fs = require('fs');
const path = require('path');

const PACK_FILE = path.join(__dirname, '..', 'pack', 'pack.json');
const UA = { 'User-Agent': 'HorizonLauncher/1.0 (pack tool)' };

function readPack() {
  return JSON.parse(fs.readFileSync(PACK_FILE, 'utf8'));
}

function writePack(pack) {
  fs.writeFileSync(PACK_FILE, `${JSON.stringify(pack, null, 2)}\n`);
}

/** Choisit la meilleure version d'un mod : une "release" de préférence, sinon la plus récente. */
function pickVersion(versions) {
  if (!Array.isArray(versions) || versions.length === 0) return null;
  return versions.find((v) => v.version_type === 'release') || versions[0];
}

/** Transforme une version Modrinth en entrée de pack. */
function modEntry(slug, title, version) {
  const file = version.files.find((f) => f.primary) || version.files[0];
  if (!file || !file.hashes || !file.hashes.sha1) throw new Error('Fichier du mod introuvable sur Modrinth.');
  return { slug, name: title || slug, file: file.filename, url: file.url, sha1: file.hashes.sha1, size: file.size };
}

function bumpVersion(version) {
  const parts = String(version || '1.0.0').split('.').map((n) => parseInt(n, 10) || 0);
  while (parts.length < 3) parts.push(0);
  parts[2] += 1;
  return parts.slice(0, 3).join('.');
}

async function getJson(url) {
  const res = await fetch(url, { headers: UA });
  if (!res.ok) throw new Error(`Réponse ${res.status} pour ${url}`);
  return res.json();
}

async function add(slug) {
  const pack = readPack();
  if (pack.loader.type === 'vanilla') {
    throw new Error('Le pack est en vanilla (sans mods). Passe d\'abord à Fabric : node tools/pack.js set-loader fabric');
  }
  const params = new URLSearchParams({
    game_versions: JSON.stringify([pack.minecraft]),
    loaders: JSON.stringify([pack.loader.type]),
  });
  const versions = await getJson(`https://api.modrinth.com/v2/project/${encodeURIComponent(slug)}/version?${params}`);
  const version = pickVersion(versions);
  if (!version) throw new Error(`"${slug}" n'a aucune version pour Minecraft ${pack.minecraft} avec ${pack.loader.type}.`);
  const project = await getJson(`https://api.modrinth.com/v2/project/${encodeURIComponent(slug)}`);

  const entry = modEntry(slug, project.title, version);
  pack.mods = (pack.mods || []).filter((m) => m.slug !== slug);
  pack.mods.push(entry);
  pack.version = bumpVersion(pack.version);
  writePack(pack);
  console.log(`Ajouté : ${entry.name} (${entry.file}). Version du pack : ${pack.version}`);

  const required = (version.dependencies || []).filter((d) => d.dependency_type === 'required' && d.project_id);
  for (const dep of required) {
    try {
      const p = await getJson(`https://api.modrinth.com/v2/project/${dep.project_id}`);
      if (!pack.mods.some((m) => m.slug === p.slug)) console.log(`⚠️  Dépendance obligatoire à ajouter aussi : node tools/pack.js add ${p.slug}`);
    } catch (_) {
      console.log(`⚠️  Ce mod a une dépendance obligatoire (${dep.project_id}).`);
    }
  }
}

async function main() {
  const [command, arg1, arg2] = process.argv.slice(2);
  const pack = readPack();
  switch (command) {
    case 'list':
      console.log(`${pack.name} v${pack.version} — Minecraft ${pack.minecraft} — ${pack.loader.type}${pack.loader.version ? ` ${pack.loader.version}` : ''}`);
      for (const m of pack.mods || []) console.log(`  - ${m.name} (${m.file})`);
      if (!(pack.mods || []).length) console.log('  (aucun mod)');
      break;
    case 'set-minecraft':
      if (!arg1) throw new Error('Indique la version : node tools/pack.js set-minecraft 26.3');
      pack.minecraft = arg1;
      pack.version = bumpVersion(pack.version);
      writePack(pack);
      console.log(`Minecraft ${arg1}. Pense à vérifier que tes mods existent pour cette version (node tools/pack.js add ...).`);
      break;
    case 'set-loader':
      if (arg1 === 'vanilla') {
        pack.loader = { type: 'vanilla' };
        pack.mods = [];
      } else if (arg1 === 'fabric') {
        let version = arg2;
        if (!version) {
          const loaders = await getJson('https://meta.fabricmc.net/v2/versions/loader');
          const stable = loaders.find((l) => l.stable);
          if (!stable) throw new Error('Aucune version stable de Fabric trouvée.');
          version = stable.version;
        }
        pack.loader = { type: 'fabric', version };
      } else {
        throw new Error('Utilisation : node tools/pack.js set-loader <fabric|vanilla> [version]');
      }
      pack.version = bumpVersion(pack.version);
      writePack(pack);
      console.log(`Chargeur : ${pack.loader.type}${pack.loader.version ? ` ${pack.loader.version}` : ''}`);
      break;
    case 'add':
      if (!arg1) throw new Error('Indique le mod : node tools/pack.js add sodium');
      await add(arg1);
      break;
    case 'remove':
      pack.mods = (pack.mods || []).filter((m) => m.slug !== arg1 && m.file !== arg1);
      pack.version = bumpVersion(pack.version);
      writePack(pack);
      console.log(`Retiré : ${arg1}. Version du pack : ${pack.version}`);
      break;
    case 'bump':
      pack.version = bumpVersion(pack.version);
      writePack(pack);
      console.log(`Version du pack : ${pack.version}`);
      break;
    default:
      console.log('Commandes : list | set-minecraft <version> | set-loader <fabric|vanilla> [version] | add <slug> | remove <slug> | bump');
  }
}

if (require.main === module) {
  main().catch((err) => {
    console.error(`Erreur : ${err.message}`);
    process.exit(1);
  });
}

module.exports = { pickVersion, modEntry, bumpVersion };
