'use strict';
/* Tests sans framework : node tests/run.js */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const { validatePack, syncPack, safeJoin, checkUrl, sha1Of } = require('../src/main/pack');
const { Settings } = require('../src/main/settings');
const { pickVersion, modEntry, bumpVersion } = require('../tools/pack');
const { parseAddress } = require('../src/main/game');
const { fetchServerStatus } = require('../src/main/status');

let passed = 0;
async function test(name, fn) {
  try {
    await fn();
    passed += 1;
    console.log(`  ✔ ${name}`);
  } catch (err) {
    console.error(`  ✘ ${name}\n    ${err.stack}`);
    process.exitCode = 1;
  }
}

const sha1 = (buf) => crypto.createHash('sha1').update(buf).digest('hex');
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'horizon-test-'));

// Faux serveur de fichiers : url -> contenu. Compte les téléchargements.
function fakeFetch(files) {
  const calls = [];
  const impl = async (url) => {
    calls.push(url);
    const key = String(url).split('?')[0];
    if (!files[key]) return new Response('introuvable', { status: 404 });
    return new Response(files[key]);
  };
  impl.calls = calls;
  return impl;
}

(async () => {
  console.log('pack.json');
  await test('accepte un pack valide et refuse un pack invalide', () => {
    assert.strictEqual(validatePack({ minecraft: '26.3' }).loader.type, 'vanilla');
    assert.throws(() => validatePack({}), /minecraft/);
    assert.throws(() => validatePack({ minecraft: '26.3', loader: { type: 'forge' } }), /loader/);
    assert.throws(() => validatePack({ minecraft: '26.3', loader: { type: 'fabric' } }), /version/);
    assert.throws(() => validatePack({ minecraft: '26.3', mods: 'oops' }), /liste/);
  });

  console.log('sécurité');
  await test('safeJoin refuse de sortir du dossier du jeu', () => {
    const base = tmp();
    assert.ok(safeJoin(base, 'mods/a.jar').startsWith(base));
    assert.throws(() => safeJoin(base, '../evil.jar'), /refusé/);
    assert.throws(() => safeJoin(base, 'mods/../../evil.jar'), /refusé/);
    assert.throws(() => safeJoin(base, '/etc/passwd'), /refusé/);
    assert.throws(() => safeJoin(base, ''), /refusé/);
  });
  await test('checkUrl : HTTPS et hôtes autorisés seulement', () => {
    const hosts = ['cdn.modrinth.com', 'github.com'];
    assert.ok(checkUrl('https://cdn.modrinth.com/data/x/a.jar', hosts));
    assert.ok(checkUrl('https://objects.github.com/x', hosts)); // sous-domaine de github.com
    assert.throws(() => checkUrl('http://cdn.modrinth.com/a.jar', hosts), /HTTPS/);
    assert.throws(() => checkUrl('https://evil.example.com/a.jar', hosts), /hôte/);
    assert.throws(() => checkUrl('https://notgithub.com/a.jar', hosts), /hôte/);
    assert.throws(() => checkUrl('pas une url', hosts), /invalide/);
  });

  console.log('synchronisation des mods');
  const A = Buffer.from('contenu du mod A');
  const B = Buffer.from('contenu du mod B');
  const B2 = Buffer.from('contenu du mod B version 2');
  const OPTS = Buffer.from('options par défaut');
  const hosts = ['cdn.test'];
  const urlA = 'https://cdn.test/a.jar';
  const urlB = 'https://cdn.test/b.jar';
  const urlB2 = 'https://cdn.test/b2.jar';
  const urlO = 'https://cdn.test/options.txt';
  const files = { [urlA]: A, [urlB]: B, [urlB2]: B2, [urlO]: OPTS };

  const base = tmp();
  const packV1 = validatePack({
    minecraft: '26.3',
    version: '1',
    mods: [
      { name: 'A', file: 'a.jar', url: urlA, sha1: sha1(A) },
      { name: 'B', file: 'b.jar', url: urlB, sha1: sha1(B) },
    ],
    files: [{ path: 'options.txt', url: urlO, sha1: sha1(OPTS), overwrite: false }],
  });

  await test('première installation : télécharge tout', async () => {
    const f = fakeFetch(files);
    const r = await syncPack(packV1, base, { allowedHosts: hosts, fetch: f });
    assert.strictEqual(r.installed, 2); // les 2 mods (le fichier de départ n'est pas suivi)
    assert.strictEqual(f.calls.length, 3);
    assert.ok(fs.existsSync(path.join(base, 'options.txt')));
    assert.deepStrictEqual(fs.readFileSync(path.join(base, 'mods/a.jar')), A);
  });
  await test('deuxième lancement : rien à retélécharger', async () => {
    const f = fakeFetch(files);
    await syncPack(packV1, base, { allowedHosts: hosts, fetch: f });
    assert.strictEqual(f.calls.length, 0);
  });
  await test('mod modifié à la main : il est remis à l\'identique', async () => {
    fs.writeFileSync(path.join(base, 'mods/a.jar'), 'triche');
    const f = fakeFetch(files);
    await syncPack(packV1, base, { allowedHosts: hosts, fetch: f });
    assert.deepStrictEqual(fs.readFileSync(path.join(base, 'mods/a.jar')), A);
    assert.strictEqual(f.calls.length, 1);
  });
  await test('options.txt du joueur n\'est jamais écrasé', async () => {
    fs.writeFileSync(path.join(base, 'options.txt'), 'mes options');
    await syncPack(packV1, base, { allowedHosts: hosts, fetch: fakeFetch(files) });
    assert.strictEqual(fs.readFileSync(path.join(base, 'options.txt'), 'utf8'), 'mes options');
  });
  await test('mise à jour du pack : remplace B, retire A, ne touche pas aux mods du joueur', async () => {
    fs.writeFileSync(path.join(base, 'mods/perso.jar'), 'mod ajouté par le joueur');
    const packV2 = validatePack({
      minecraft: '26.3',
      version: '2',
      mods: [{ name: 'B', file: 'b2.jar', url: urlB2, sha1: sha1(B2) }],
      files: [],
    });
    const r = await syncPack(packV2, base, { allowedHosts: hosts, fetch: fakeFetch(files) });
    assert.ok(!fs.existsSync(path.join(base, 'mods/a.jar')), 'A doit être retiré');
    assert.ok(!fs.existsSync(path.join(base, 'mods/b.jar')), 'B v1 doit être retiré');
    assert.ok(fs.existsSync(path.join(base, 'mods/b2.jar')));
    assert.ok(fs.existsSync(path.join(base, 'mods/perso.jar')), 'le mod du joueur doit rester');
    assert.ok(fs.existsSync(path.join(base, 'options.txt')), 'le fichier du joueur doit rester');
    assert.ok(r.removed >= 2);
  });
  await test('fichier corrompu : refusé et rien n\'est installé', async () => {
    const dir = tmp();
    const bad = validatePack({ minecraft: '26.3', mods: [{ name: 'A', file: 'a.jar', url: urlA, sha1: sha1(B) }] });
    await assert.rejects(() => syncPack(bad, dir, { allowedHosts: hosts, fetch: fakeFetch(files) }), /corrompu|empreinte/);
    assert.ok(!fs.existsSync(path.join(dir, 'mods/a.jar')));
    assert.ok(!fs.existsSync(path.join(dir, 'mods/a.jar.download')));
  });
  await test('pack malveillant : chemin hors dossier et hôte inconnu refusés', async () => {
    const dir = tmp();
    const evilPath = validatePack({ minecraft: '26.3', files: [{ path: '../../evil.txt', url: urlA }] });
    await assert.rejects(() => syncPack(evilPath, dir, { allowedHosts: hosts, fetch: fakeFetch(files) }), /refusé/);
    const evilHost = validatePack({ minecraft: '26.3', mods: [{ file: 'x.jar', url: 'https://evil.example.com/x.jar' }] });
    await assert.rejects(() => syncPack(evilHost, dir, { allowedHosts: hosts, fetch: fakeFetch(files) }), /autorisé/);
  });
  await test('sha1Of calcule la bonne empreinte', async () => {
    const f = path.join(tmp(), 'x');
    fs.writeFileSync(f, A);
    assert.strictEqual(await sha1Of(f), sha1(A));
  });

  console.log('réglages');
  await test('les valeurs sont bornées et enregistrées', () => {
    const file = path.join(tmp(), 'settings.json');
    const s = new Settings(file);
    assert.strictEqual(s.get('maxMemoryMb'), 4096);
    s.set({ maxMemoryMb: 999999 });
    assert.strictEqual(s.get('maxMemoryMb'), 32768);
    s.set({ maxMemoryMb: 10 });
    assert.strictEqual(s.get('maxMemoryMb'), 1024);
    s.set({ maxMemoryMb: 'abc' });
    assert.strictEqual(s.get('maxMemoryMb'), 1024);
    s.set({ autoJoin: false, lastUsername: 'Steve' });
    const reloaded = new Settings(file);
    assert.strictEqual(reloaded.get('autoJoin'), false);
    assert.strictEqual(reloaded.get('lastUsername'), 'Steve');
    assert.ok(reloaded.get('minMemoryMb') <= reloaded.get('maxMemoryMb'));
  });
  await test('fichier de réglages abîmé : valeurs par défaut', () => {
    const file = path.join(tmp(), 'settings.json');
    fs.writeFileSync(file, '{ pas du json');
    assert.strictEqual(new Settings(file).get('maxMemoryMb'), 4096);
  });

  console.log('outil de pack');
  await test('pickVersion préfère une release', () => {
    assert.strictEqual(pickVersion([{ version_type: 'beta', id: 1 }, { version_type: 'release', id: 2 }]).id, 2);
    assert.strictEqual(pickVersion([{ version_type: 'beta', id: 1 }]).id, 1);
    assert.strictEqual(pickVersion([]), null);
  });
  await test('modEntry lit le fichier principal et son SHA-1', () => {
    const e = modEntry('sodium', 'Sodium', {
      files: [{ primary: false, filename: 'x.jar', hashes: { sha1: 'aa' } }, { primary: true, filename: 'sodium.jar', url: 'https://cdn.modrinth.com/s.jar', hashes: { sha1: 'bb' }, size: 5 }],
    });
    assert.deepStrictEqual(e, { slug: 'sodium', name: 'Sodium', file: 'sodium.jar', url: 'https://cdn.modrinth.com/s.jar', sha1: 'bb', size: 5 });
  });
  await test('bumpVersion incrémente le dernier chiffre', () => {
    assert.strictEqual(bumpVersion('1.0.0'), '1.0.1');
    assert.strictEqual(bumpVersion('1.2'), '1.2.1');
    assert.strictEqual(bumpVersion(undefined), '1.0.1');
  });

  console.log('divers');
  await test('parseAddress', () => {
    assert.deepStrictEqual(parseAddress('mc.exemple.fr'), { host: 'mc.exemple.fr', port: 25565 });
    assert.deepStrictEqual(parseAddress('mc.exemple.fr:25570'), { host: 'mc.exemple.fr', port: 25570 });
    assert.deepStrictEqual(parseAddress('[2001:db8::1]:25570'), { host: '2001:db8::1', port: 25570 });
    assert.throws(() => parseAddress('mc.exemple.fr:99999'), /port/);
    assert.throws(() => parseAddress('https://mc.exemple.fr'), /invalide/);
  });
  await test('état du serveur : ne plante jamais', async () => {
    const ok = await fetchServerStatus('https://api/', 'a.b', async () => new Response(JSON.stringify({ online: true, players: { online: 3, max: 20 } })));
    assert.deepStrictEqual(ok, { known: true, online: true, players: 3, max: 20 });
    const down = await fetchServerStatus('https://api/', 'a.b', async () => { throw new Error('réseau'); });
    assert.deepStrictEqual(down, { online: false, known: false });
    const http500 = await fetchServerStatus('https://api/', 'a.b', async () => new Response('x', { status: 500 }));
    assert.strictEqual(http500.known, false);
  });

  console.log(`\n${passed} test(s) réussi(s)${process.exitCode ? ' — ÉCHECS ci-dessus' : ''}`);
})();
