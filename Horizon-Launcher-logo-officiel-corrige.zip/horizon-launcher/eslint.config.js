const globals = require('globals');
module.exports = [{ ignores: ['node_modules/**','dist/**'] },{
  files: ['**/*.js'],
  languageOptions: { ecmaVersion: 2023, sourceType: 'commonjs', globals: { ...globals.node, ...globals.browser } },
  rules: { 'no-undef': 'error', 'no-unused-vars': ['warn', { args: 'none', caughtErrors: 'none' }], 'no-dupe-keys': 'error', 'no-unreachable': 'error', 'no-redeclare': 'error', 'no-const-assign': 'error', 'no-self-assign': 'error', 'no-unsafe-finally': 'error', 'require-atomic-updates': 'off', 'use-isnan': 'error', 'valid-typeof': 'error', 'no-empty': 'off' }
}];
