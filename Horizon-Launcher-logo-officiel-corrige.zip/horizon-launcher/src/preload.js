'use strict';
const { contextBridge, ipcRenderer } = require('electron');

// Seules ces fonctions sont accessibles depuis la page : rien d'autre de Node n'y est exposé.
function on(channel, callback) {
  const listener = (_event, payload) => callback(payload);
  ipcRenderer.on(channel, listener);
  return () => ipcRenderer.removeListener(channel, listener);
}

contextBridge.exposeInMainWorld('horizon', {
  info: () => ipcRenderer.invoke('app:info'),
  authStatus: () => ipcRenderer.invoke('auth:status'),
  login: () => ipcRenderer.invoke('auth:login'),
  logout: () => ipcRenderer.invoke('auth:logout'),
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (patch) => ipcRenderer.invoke('settings:set', patch),
  serverStatus: () => ipcRenderer.invoke('server:status'),
  play: () => ipcRenderer.invoke('game:play'),
  open: (what) => ipcRenderer.invoke('shell:open', what),
  openExternal: (url) => ipcRenderer.invoke('shell:openExternal', url),
  installUpdate: () => ipcRenderer.invoke('update:install'),
  onAuthCode: (cb) => on('auth:code', cb),
  onAuthDone: (cb) => on('auth:done', cb),
  onStatus: (cb) => on('game:status', cb),
  onGameState: (cb) => on('game:state', cb),
  onUpdateReady: (cb) => on('update:ready', cb),
  onUpdateError: (cb) => on('update:error', cb),
});
