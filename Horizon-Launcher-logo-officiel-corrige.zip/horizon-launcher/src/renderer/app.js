'use strict';
/* Interface du lanceur. Tout le texte reçu de l'extérieur est inséré avec textContent (jamais innerHTML). */
const $ = (id) => document.getElementById(id);
const api = window.horizon;

let info = null;
let playing = false;
let codeUrl = '';

function show(view) {
  $('view-login').classList.toggle('hidden', view !== 'login');
  $('view-home').classList.toggle('hidden', view !== 'home');
}

function setUser(name) {
  $('user-box').classList.toggle('hidden', !name);
  $('user-name').textContent = name || '';
}

function showMessage(text, isError) {
  const box = $('game-message');
  box.textContent = text || '';
  box.classList.toggle('hidden', !text);
  box.classList.toggle('error', !!isError);
}

function setProgress(text) {
  $('progress').classList.toggle('hidden', !text);
  $('progress-text').textContent = text || '';
}

function setPlaying(value) {
  playing = value;
  $('play-btn').disabled = value;
  $('play-btn').textContent = value ? 'EN COURS...' : 'JOUER';
}

// ---------------- Connexion ----------------

async function doLogin() {
  $('login-btn').disabled = true;
  $('login-error').classList.add('hidden');
  try {
    const result = await api.login();
    $('code-box').classList.add('hidden');
    if (result.ok) {
      setUser(result.name);
      show('home');
    } else {
      $('login-error').textContent = result.error || 'Connexion impossible.';
      $('login-error').classList.remove('hidden');
    }
  } catch (err) {
    $('login-error').textContent = err && err.message ? err.message : 'Connexion impossible.';
    $('login-error').classList.remove('hidden');
  } finally {
    $('login-btn').disabled = false;
  }
}

api.onAuthCode(({ code, url }) => {
  codeUrl = url;
  $('code-value').textContent = code;
  $('code-box').classList.remove('hidden');
});
api.onAuthDone(({ name }) => setUser(name));

// ---------------- Serveur ----------------

async function refreshStatus() {
  const s = await api.serverStatus();
  const dot = $('status-dot');
  if (!s.known) {
    dot.className = 'dot off';
    $('status-text').textContent = 'État du serveur inconnu';
  } else if (s.online) {
    dot.className = 'dot';
    $('status-text').textContent = `En ligne · ${s.players}/${s.max} joueurs`;
  } else {
    dot.className = 'dot off';
    $('status-text').textContent = 'Serveur hors ligne';
  }
}

// ---------------- Jouer ----------------

const STEP_LABELS = {
  pack: 'Pack',
  session: 'Compte',
  files: 'Mods',
  game: 'Minecraft',
  java: 'Java',
  launch: 'Lancement',
};

api.onStatus(({ step, detail }) => {
  setProgress(`${STEP_LABELS[step] || ''} · ${detail}`);
});

api.onGameState(({ state, code, tail }) => {
  if (state === 'playing') {
    setProgress('');
    showMessage('Minecraft est lancé. Bon jeu !');
  } else if (state === 'stopped') {
    setPlaying(false);
    showMessage('Le jeu s\'est fermé.');
  } else if (state === 'crashed') {
    setPlaying(false);
    showMessage(`Le jeu s'est arrêté de façon inattendue (code ${code}). Les dernières lignes du journal :`, true);
    $('crash-log').textContent = tail || '';
    $('crash-log').classList.remove('hidden');
  }
});

async function doPlay() {
  showMessage('');
  $('crash-log').classList.add('hidden');
  setPlaying(true);
  setProgress('Préparation...');
  try {
    const result = await api.play();
    if (!result.ok) {
      setPlaying(false);
      setProgress('');
      showMessage(result.error || 'Impossible de lancer le jeu.', true);
    }
  } catch (err) {
    setPlaying(false);
    setProgress('');
    showMessage(err && err.message ? err.message : 'Impossible de lancer le jeu.', true);
  }
}

// ---------------- Réglages ----------------

function ramLabel(mb) {
  return `${(mb / 1024).toFixed(mb % 1024 === 0 ? 0 : 1)} Go`;
}

async function loadSettings() {
  const s = await api.getSettings();
  $('ram').value = s.maxMemoryMb;
  $('ram-value').textContent = ramLabel(s.maxMemoryMb);
  $('autojoin').checked = s.autoJoin;
}

$('ram').addEventListener('input', () => {
  $('ram-value').textContent = ramLabel(Number($('ram').value));
});
$('ram').addEventListener('change', () => api.setSettings({ maxMemoryMb: Number($('ram').value) }));
$('autojoin').addEventListener('change', () => api.setSettings({ autoJoin: $('autojoin').checked }));

// ---------------- Boutons ----------------

$('login-btn').addEventListener('click', doLogin);
$('play-btn').addEventListener('click', doPlay);
$('open-game').addEventListener('click', () => api.open('game'));
$('open-logs').addEventListener('click', () => api.open('logs'));
$('discord-btn').addEventListener('click', () => info && api.openExternal(info.discordInviteUrl));
$('logout-btn').addEventListener('click', async () => {
  if (playing) return;
  await api.logout();
  setUser('');
  show('login');
});
$('code-copy').addEventListener('click', () => navigator.clipboard.writeText($('code-value').textContent));
$('code-link').addEventListener('click', (event) => {
  event.preventDefault();
  if (codeUrl) api.openExternal(codeUrl);
});
$('update-btn').addEventListener('click', () => api.installUpdate());
api.onUpdateReady(({ version }) => {
  $('update-text').textContent = `Mise à jour ${version} prête.`;
  $('update-banner').classList.remove('hidden');
});
api.onUpdateError(({ message }) => {
  showMessage(`Mise à jour : ${message || 'indisponible.'}`, true);
});

// ---------------- Démarrage ----------------

(async function init() {
  info = await api.info();
  document.title = info.serverName;
  $('server-name').textContent = info.serverName;
  $('hero-title').textContent = info.serverName;
  $('app-version').textContent = `Lanceur v${info.version}`;
  $('server-address').textContent = info.serverAddress;
  if (info.discordInviteUrl) $('discord-btn').classList.remove('hidden');

  await loadSettings();
  const auth = await api.authStatus();
  if (auth.loggedIn) {
    setUser(auth.name);
    show('home');
  } else {
    show('login');
  }
  refreshStatus();
  setInterval(refreshStatus, 60_000);
})();
