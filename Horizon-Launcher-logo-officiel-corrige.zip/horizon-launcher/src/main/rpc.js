'use strict';
const { Client } = require('@xhayper/discord-rpc');

/**
 * Discord Rich Presence : affiche « Joue à Horizon SMP » sur le profil Discord du joueur.
 * Discord doit être ouvert sur l'ordinateur ; sinon on réessaie discrètement toutes les 30 secondes.
 */
class Presence {
  constructor(appId, serverName) {
    this.appId = appId;
    this.serverName = serverName;
    this.client = null;
    this.ready = false;
    this.activity = null;
    this.timer = null;
    this.stopped = false;
  }

  start() {
    if (!this.appId || /^0*$/.test(this.appId)) return; // pas d'application Discord configurée
    this.connect();
  }

  async connect() {
    if (this.stopped) return;
    try {
      this.client = new Client({ clientId: this.appId });
      this.client.on('ready', () => {
        this.ready = true;
        this.apply();
      });
      this.client.on('disconnected', () => {
        this.ready = false;
        this.retry();
      });
      await this.client.login();
    } catch (_) {
      this.ready = false;
      this.retry(); // Discord pas ouvert : on réessaiera
    }
  }

  retry() {
    if (this.stopped || this.timer) return;
    this.timer = setTimeout(() => {
      this.timer = null;
      this.connect();
    }, 30_000);
  }

  /** state : { details, state, startTimestamp } ou null pour effacer */
  set(activity) {
    this.activity = activity;
    this.apply();
  }

  async apply() {
    if (!this.ready || !this.client || !this.client.user) return;
    try {
      if (!this.activity) {
        await this.client.user.clearActivity();
      } else {
        await this.client.user.setActivity({
          details: this.activity.details,
          state: this.activity.state,
          startTimestamp: this.activity.startTimestamp,
          largeImageKey: 'logo', // à envoyer dans le portail Discord (voir README)
          largeImageText: this.serverName,
        });
      }
    } catch (_) {
      // Discord a fermé la connexion : sera retenté à la reconnexion
    }
  }

  async stop() {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    try {
      if (this.client) await this.client.destroy();
    } catch (_) {
      // déjà fermé
    }
  }
}

module.exports = { Presence };
