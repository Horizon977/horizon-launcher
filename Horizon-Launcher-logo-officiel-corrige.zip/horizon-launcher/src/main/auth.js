'use strict';
const fs = require('fs');
const { Authflow, Titles } = require('prismarine-auth');

/**
 * Connexion avec un compte Microsoft (celui qui possède Minecraft Java) par "code appareil" :
 * le joueur ouvre une page Microsoft, tape un code, et se connecte là-bas. Le lanceur ne voit JAMAIS son mot de passe.
 * Les jetons de connexion sont gardés dans le dossier `cacheDir` pour ne pas redemander à chaque fois.
 */
class Auth {
  constructor(cacheDir, options = {}) {
    this.cacheDir = cacheDir;
    this.clientId = options.clientId || null; // identifiant d'application Azure (voir README)
  }

  hasSession() {
    try {
      return fs.existsSync(this.cacheDir) && fs.readdirSync(this.cacheDir).length > 0;
    } catch (_) {
      return false;
    }
  }

  /** Retourne { token, profile: { id, name } }. onCode({ code, url }) est appelé si le joueur doit se (re)connecter. */
  async getSession(onCode) {
    fs.mkdirSync(this.cacheDir, { recursive: true });
    const flowOptions = this.clientId
      ? { flow: 'msal', authTitle: this.clientId, deviceType: 'Win32' }
      : { flow: 'live', authTitle: Titles.MinecraftJava, deviceType: 'Win32' };

    const flow = new Authflow('horizon', this.cacheDir, flowOptions, (res) => {
      onCode({ code: res.user_code, url: res.verification_uri, message: res.message });
    });

    const result = await flow.getMinecraftJavaToken({ fetchProfile: true, fetchEntitlements: true });
    const profile = result && result.profile;
    if (!profile || !profile.id || !profile.name) {
      throw new Error('Ce compte Microsoft ne possède pas Minecraft Java Edition (aucun profil trouvé).');
    }
    return { token: result.token, profile: { id: profile.id, name: profile.name } };
  }

  logout() {
    fs.rmSync(this.cacheDir, { recursive: true, force: true });
  }
}

module.exports = { Auth };
