'use strict';
const { app, BrowserWindow, ipcMain, shell } = require('electron');
const { autoUpdater } = require('electron-updater');
const fs = require('fs');
const path = require('path');

const config = require('../config.json');
const { Settings } = require('./settings');
const { Auth } = require('./auth');
const { Presence } = require('./rpc');
const { fetchServerStatus } = require('./status');
const { fetchPack, syncPack } = require('./pack');
const { ensureGame, ensureJava, launchGame } = require('./game');

// --- Dossiers (tout reste dans %APPDATA%/HorizonSMP) ---
const dataDir = path.join(app.getPath('appData'), 'HorizonSMP');
const dirs = {
  root: path.join(dataDir, 'minecraft'),     // versions, bibliothèques, ressources
  instance: path.join(dataDir, 'instance'),  // mods, mondes, options
  runtime: path.join(dataDir, 'runtime'),    // Java
  auth: path.join(dataDir, 'auth'),          // jetons de connexion
  logs: path.join(dataDir, 'logs'),
};

const settings = new Settings(path.join(dataDir, 'settings.json'));
const auth = new Auth(dirs.auth, { clientId: config.microsoftClientId || null });
const presence = new Presence(config.discordAppId, config.serverName);

let win = null;
let busy = false;       // une préparation / un jeu est en cours
let gameProcess = null;

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

function createWindow() {
  win = new BrowserWindow({
    width: 980,
    height: 640,
    minWidth: 820,
    minHeight: 560,
    backgroundColor: '#14101c',
    title: config.serverName,
    icon: path.join(__dirname, '..', 'renderer', 'logo-horizon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, '..', 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  // Les liens s'ouvrent dans le navigateur, jamais dans la fenêtre du lanceur
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (event) => event.preventDefault());
}

// ------------------------------------------------------------------
// Connexion Microsoft
// ------------------------------------------------------------------

function onDeviceCode({ code, url }) {
  send('auth:code', { code, url });
  if (/^https:\/\//.test(url)) shell.openExternal(url);
}

ipcMain.handle('app:info', () => ({
  serverName: config.serverName,
  serverAddress: config.serverAddress,
  discordInviteUrl: config.discordInviteUrl || '',
  version: app.getVersion(),
}));

ipcMain.handle('auth:status', () => ({
  loggedIn: auth.hasSession(),
  name: settings.get('lastUsername'),
}));

ipcMain.handle('auth:login', async () => {
  try {
    const session = await auth.getSession(onDeviceCode);
    settings.set({ lastUsername: session.profile.name });
    return { ok: true, name: session.profile.name };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

ipcMain.handle('auth:logout', () => {
  auth.logout();
  settings.set({ lastUsername: '' });
  return { ok: true };
});

// ------------------------------------------------------------------
// Réglages, état du serveur, dossiers
// ------------------------------------------------------------------

ipcMain.handle('settings:get', () => settings.get());
ipcMain.handle('settings:set', (_event, patch) => settings.set(patch || {}));
ipcMain.handle('server:status', () => fetchServerStatus(config.statusApi, config.serverAddress));
ipcMain.handle('shell:open', (_event, what) => {
  const target = what === 'logs' ? dirs.logs : dirs.instance;
  fs.mkdirSync(target, { recursive: true });
  return shell.openPath(target);
});
ipcMain.handle('shell:openExternal', (_event, url) => {
  if (typeof url === 'string' && /^https:\/\//.test(url)) shell.openExternal(url);
});
ipcMain.handle('update:install', () => autoUpdater.quitAndInstall());

// ------------------------------------------------------------------
// Jouer : pack -> Minecraft -> Java -> connexion -> lancement
// ------------------------------------------------------------------

function status(step, detail) {
  send('game:status', { step, detail });
}

ipcMain.handle('game:play', async () => {
  if (busy) return { ok: false, error: 'Une opération est déjà en cours.' };
  busy = true;
  try {
    status('pack', 'Recherche des mises à jour du pack...');
    const pack = await fetchPack(config.packUrl);

    status('session', 'Connexion à ton compte Microsoft...');
    const session = await auth.getSession(onDeviceCode);
    settings.set({ lastUsername: session.profile.name });
    send('auth:done', { name: session.profile.name });

    status('files', 'Mise à jour des mods...');
    await syncPack(pack, dirs.instance, {
      allowedHosts: config.allowedDownloadHosts,
      onStatus: (detail) => status('files', detail),
    });

    const versionId = await ensureGame(pack, dirs.root, (detail) => status('game', detail));
    const javaPath = await ensureJava(dirs.root, versionId, dirs.runtime, settings.get('javaPath'), (detail) => status('java', detail));

    status('launch', 'Lancement de Minecraft...');
    const memory = settings.get();
    gameProcess = await launchGame({
      root: dirs.root,
      instanceDir: dirs.instance,
      versionId,
      javaPath,
      session,
      minMemoryMb: Math.min(memory.minMemoryMb, memory.maxMemoryMb),
      maxMemoryMb: memory.maxMemoryMb,
      serverAddress: (pack.server && pack.server.address) || config.serverAddress,
      autoJoin: memory.autoJoin,
    });

    // Journal du jeu + détection d'un plantage
    fs.mkdirSync(dirs.logs, { recursive: true });
    const logFile = path.join(dirs.logs, 'dernier-lancement.log');
    const log = fs.createWriteStream(logFile);
    const tail = [];
    const keep = (chunk) => {
      log.write(chunk);
      tail.push(...String(chunk).split(/\r?\n/).filter(Boolean));
      if (tail.length > 40) tail.splice(0, tail.length - 40);
    };
    if (gameProcess.stdout) gameProcess.stdout.on('data', keep);
    if (gameProcess.stderr) gameProcess.stderr.on('data', keep);

    const startedAt = Date.now();
    presence.set({ details: `Joue à ${config.serverName}`, state: 'En jeu', startTimestamp: startedAt });
    send('game:state', { state: 'playing' });

    let finished = false;
    const finishGame = (code, error) => {
      if (finished) return;
      finished = true;
      log.end();
      gameProcess = null;
      busy = false;
      presence.set(null);
      if (error) {
        tail.push(`Erreur du processus Minecraft : ${error.message || error}`);
        send('game:state', { state: 'crashed', code: null, tail: tail.slice(-12).join('\n') });
      } else if (code === 0 || code === null) {
        send('game:state', { state: 'stopped' });
      } else {
        send('game:state', { state: 'crashed', code, tail: tail.slice(-12).join('\n') });
      }
    };
    gameProcess.once('error', (err) => finishGame(null, err));
    gameProcess.once('exit', (code) => finishGame(code, null));
    return { ok: true };
  } catch (err) {
    busy = false;
    presence.set(null);
    return { ok: false, error: err && err.message ? err.message : String(err) };
  }
});

// ------------------------------------------------------------------
// Démarrage de l'application
// ------------------------------------------------------------------

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
  });

  app.whenReady().then(() => {
    createWindow();
    presence.start();

    // Mises à jour automatiques du lanceur (versions publiées sur GitHub)
    if (app.isPackaged) {
      autoUpdater.autoDownload = true;
      autoUpdater.on('update-downloaded', (info) => send('update:ready', { version: info.version }));
      autoUpdater.on('error', (err) => send('update:error', { message: err && err.message ? err.message : 'Mise à jour indisponible.' }));
      autoUpdater.checkForUpdates().catch((err) => {
        send('update:error', { message: err && err.message ? err.message : 'Vérification des mises à jour impossible.' });
      });
    }

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
  });

  app.on('window-all-closed', () => {
    presence.stop();
    if (process.platform !== 'darwin') app.quit();
  });
}
