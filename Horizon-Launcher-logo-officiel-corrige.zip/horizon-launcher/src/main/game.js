'use strict';
const fs = require('fs');
const path = require('path');
const { Version, launch, diagnose } = require('@xmcl/core');
const {
  getVersionList,
  installTask,
  installDependenciesTask,
  installFabric,
  fetchJavaRuntimeManifest,
  installJavaRuntimeTask,
} = require('@xmcl/installer');

/** Affiche "12.3 Mo" pendant un téléchargement, sans inonder l'interface de messages. */
function progressContext(onStatus, label) {
  let bytes = 0;
  let last = 0;
  return {
    onUpdate(_task, chunk) {
      bytes += chunk || 0;
      const now = Date.now();
      if (now - last > 400) {
        last = now;
        onStatus(`${label} (${(bytes / 1048576).toFixed(1)} Mo)`);
      }
    },
  };
}

function parseAddress(address) {
  const raw = String(address || '').trim();
  if (!raw || /[\s/\\@]/.test(raw)) throw new Error('Adresse du serveur invalide.');
  let host = raw;
  let port = 25565;
  if (raw.startsWith('[')) {
    const match = raw.match(/^\[([0-9a-f:]+)\](?::(\d{1,5}))?$/i);
    if (!match) throw new Error('Adresse IPv6 invalide.');
    host = match[1];
    if (match[2]) port = Number(match[2]);
  } else {
    const match = raw.match(/^([^:]+)(?::(\d{1,5}))?$/);
    if (!match) throw new Error('Adresse du serveur invalide.');
    host = match[1];
    if (match[2]) port = Number(match[2]);
  }
  if (!host || !Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('Adresse ou port du serveur invalide.');
  }
  return { host, port };
}

async function isInstalled(root, versionId) {
  try {
    const report = await diagnose(versionId, root);
    return report.issues.length === 0;
  } catch (_) {
    return false; // version jamais installée
  }
}

function javaExecutable(dir) {
  const candidates =
    process.platform === 'win32'
      ? ['bin/javaw.exe', 'bin/java.exe']
      : process.platform === 'darwin'
        ? ['jre.bundle/Contents/Home/bin/java', 'bin/java']
        : ['bin/java'];
  for (const c of candidates) {
    const p = path.join(dir, c);
    if (fs.existsSync(p)) return p;
  }
  return null;
}

/** Installe la version voulue de Minecraft (et Fabric si le pack le demande). Retourne l'identifiant de version à lancer. */
async function ensureGame(pack, root, onStatus) {
  let meta = null;
  try {
    const list = await getVersionList();
    meta = list.versions.find((v) => v.id === pack.minecraft) || null;
    if (!meta && !(await isInstalled(root, pack.minecraft))) {
      throw new Error(`La version ${pack.minecraft} de Minecraft est introuvable chez Mojang.`);
    }
  } catch (err) {
    // Pas d'accès à la liste de Mojang (hors ligne) : on continue seulement si tout est déjà installé
    if (!(await isInstalled(root, pack.minecraft))) throw err;
  }

  if (!(await isInstalled(root, pack.minecraft))) {
    onStatus(`Installation de Minecraft ${pack.minecraft}...`);
    await installTask(meta, root).startAndWait(progressContext(onStatus, `Installation de Minecraft ${pack.minecraft}`));
  }

  let versionId = pack.minecraft;
  if (pack.loader && pack.loader.type === 'fabric') {
    const fabricId = `fabric-loader-${pack.loader.version}-${pack.minecraft}`;
    if (await isInstalled(root, fabricId)) {
      versionId = fabricId;
    } else {
      onStatus(`Installation de Fabric ${pack.loader.version}...`);
      versionId = await installFabric({ minecraftVersion: pack.minecraft, version: pack.loader.version, minecraft: root });
      const resolved = await Version.parse(root, versionId);
      await installDependenciesTask(resolved).startAndWait(progressContext(onStatus, 'Téléchargement des bibliothèques Fabric'));
    }
  }
  return versionId;
}

/** Trouve (ou télécharge, depuis Mojang) la bonne version de Java pour cette version du jeu. */
async function ensureJava(root, versionId, runtimeDir, javaOverride, onStatus) {
  if (javaOverride) return javaOverride;
  const resolved = await Version.parse(root, versionId);
  const { component, majorVersion } = resolved.javaVersion || { component: 'jre-legacy', majorVersion: 8 };
  const destination = path.join(runtimeDir, component);

  let exe = javaExecutable(destination);
  if (exe) return exe;

  onStatus(`Téléchargement de Java ${majorVersion}...`);
  const manifest = await fetchJavaRuntimeManifest({ target: component });
  await installJavaRuntimeTask({ destination, manifest }).startAndWait(progressContext(onStatus, `Téléchargement de Java ${majorVersion}`));
  exe = javaExecutable(destination);
  if (!exe) throw new Error('Java a été téléchargé mais le programme est introuvable.');
  if (process.platform !== 'win32') fs.chmodSync(exe, 0o755);
  return exe;
}

/** Lance le jeu. Retourne le processus (stdout/stderr à lire, évènement "exit" à surveiller). */
async function launchGame(opts) {
  const { root, instanceDir, versionId, javaPath, session, minMemoryMb, maxMemoryMb, serverAddress, autoJoin } = opts;
  const resolved = await Version.parse(root, versionId);

  const launchOptions = {
    gamePath: instanceDir,
    resourcePath: root,
    javaPath,
    version: resolved,
    gameProfile: { id: session.profile.id, name: session.profile.name },
    accessToken: session.token,
    userType: 'msa', // compte Microsoft
    launcherName: 'HorizonLauncher',
    launcherBrand: 'HorizonLauncher',
    minMemory: minMemoryMb,
    maxMemory: maxMemoryMb,
    extraExecOption: { windowsHide: true },
  };

  // Connexion automatique au serveur : "quick play" sur les versions récentes, ancien système sinon
  if (autoJoin && serverAddress) {
    const { host, port } = parseAddress(serverAddress);
    const supportsQuickPlay = JSON.stringify(resolved.arguments || {}).includes('quickPlayMultiplayer');
    if (supportsQuickPlay) launchOptions.extraMCArgs = ['--quickPlayMultiplayer', `${host}:${port}`];
    else launchOptions.server = { ip: host, port };
  }

  return launch(launchOptions);
}

module.exports = { ensureGame, ensureJava, launchGame, parseAddress, javaExecutable };
