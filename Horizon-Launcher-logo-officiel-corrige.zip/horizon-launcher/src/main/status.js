'use strict';

/** État du serveur Minecraft (en ligne ? combien de joueurs ?) via une API publique. Ne plante jamais. */
async function fetchServerStatus(apiBase, address, fetchImpl = fetch) {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    const res = await fetchImpl(`${apiBase}${encodeURIComponent(address)}`, {
      signal: controller.signal,
      headers: { 'User-Agent': 'HorizonLauncher' },
    });
    clearTimeout(timeout);
    if (!res.ok) return { online: false, known: false };
    const data = await res.json();
    return {
      known: true,
      online: !!data.online,
      players: data.players ? data.players.online : 0,
      max: data.players ? data.players.max : 0,
    };
  } catch (_) {
    return { online: false, known: false };
  }
}

module.exports = { fetchServerStatus };
