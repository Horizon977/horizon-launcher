'use strict';
const fs = require('fs');
const path = require('path');

const DEFAULTS = {
  minMemoryMb: 1024,
  maxMemoryMb: 4096,
  autoJoin: true,
  javaPath: '', // vide = Java fourni par Mojang (recommandé)
  lastUsername: '',
};

class Settings {
  constructor(file) {
    this.file = file;
    this.data = { ...DEFAULTS };
    try {
      const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
      this.data = { ...DEFAULTS, ...raw };
    } catch (_) {
      // premier lancement ou fichier abîmé : valeurs par défaut
    }
  }

  get(key) {
    return key ? this.data[key] : { ...this.data };
  }

  /** Enregistre quelques réglages après les avoir vérifiés. */
  set(patch) {
    const next = { ...this.data };
    if (patch.maxMemoryMb !== undefined) {
      const v = Math.round(Number(patch.maxMemoryMb));
      if (Number.isFinite(v)) next.maxMemoryMb = Math.min(32768, Math.max(1024, v));
    }
    if (patch.minMemoryMb !== undefined) {
      const v = Math.round(Number(patch.minMemoryMb));
      if (Number.isFinite(v)) next.minMemoryMb = Math.min(next.maxMemoryMb, Math.max(512, v));
    }
    if (patch.autoJoin !== undefined) next.autoJoin = !!patch.autoJoin;
    if (patch.javaPath !== undefined) next.javaPath = String(patch.javaPath || '');
    if (patch.lastUsername !== undefined) next.lastUsername = String(patch.lastUsername || '').slice(0, 32);
    next.minMemoryMb = Math.min(next.minMemoryMb, next.maxMemoryMb);
    this.data = next;
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    fs.writeFileSync(this.file, JSON.stringify(next, null, 2));
    return { ...next };
  }
}

module.exports = { Settings, DEFAULTS };
