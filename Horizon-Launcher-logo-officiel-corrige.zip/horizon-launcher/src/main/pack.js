'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Readable } = require('stream');
const { pipeline } = require('stream/promises');

const MANIFEST_NAME = '.horizon-installed.json';
const MAX_FILE_BYTES = 512 * 1024 * 1024;
const MAX_REDIRECTS = 5;

// ------------------------------------------------------------------
// Lecture et vérification de pack.json
// ------------------------------------------------------------------

function validatePack(pack) {
  if (!pack || typeof pack !== 'object') throw new Error('pack.json illisible.');
  if (typeof pack.minecraft !== 'string' || !pack.minecraft) throw new Error('pack.json : "minecraft" manquant.');
  if (pack.loader != null) {
    if (typeof pack.loader !== 'object' || !['vanilla', 'fabric'].includes(pack.loader.type)) {
      throw new Error('pack.json : "loader.type" doit être "vanilla" ou "fabric".');
    }
    if (pack.loader.type === 'fabric' && !pack.loader.version) throw new Error('pack.json : "loader.version" manquant pour Fabric.');
  }
  for (const key of ['mods', 'files']) {
    if (pack[key] != null && !Array.isArray(pack[key])) throw new Error(`pack.json : "${key}" doit être une liste.`);
  }
  return {
    name: pack.name || 'Pack',
    version: String(pack.version || '0'),
    minecraft: pack.minecraft,
    loader: pack.loader || { type: 'vanilla' },
    server: pack.server || null,
    memory: pack.memory || null,
    mods: pack.mods || [],
    files: pack.files || [],
  };
}

async function fetchPack(url, fetchImpl = fetch) {
  const sep = url.includes('?') ? '&' : '?';
  const res = await fetchImpl(`${url}${sep}t=${Date.now()}`, { headers: { 'Cache-Control': 'no-cache' } });
  if (!res.ok) throw new Error(`Impossible de lire le pack (HTTP ${res.status}).`);
  return validatePack(await res.json());
}

// ------------------------------------------------------------------
// Sécurité
// ------------------------------------------------------------------

/** Joint un chemin relatif du pack à un dossier, sans jamais pouvoir en sortir ("../", chemin absolu...). */
function safeJoin(base, relative) {
  if (typeof relative !== 'string' || !relative || path.isAbsolute(relative) || relative.includes('\0')) {
    throw new Error(`Chemin refusé dans le pack : ${relative}`);
  }
  const target = path.resolve(base, relative);
  const root = path.resolve(base) + path.sep;
  if (!target.startsWith(root)) throw new Error(`Chemin refusé dans le pack : ${relative}`);
  return target;
}

function checkUrl(url, allowedHosts) {
  let parsed;
  try { parsed = new URL(url); }
  catch (_) { throw new Error(`Adresse invalide dans le pack : ${url}`); }
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password || parsed.port && parsed.port !== '443') {
    throw new Error(`Adresse HTTPS non autorisée : ${url}`);
  }
  const hosts = Array.isArray(allowedHosts) ? allowedHosts : [];
  const host = parsed.hostname.toLowerCase();
  const ok = hosts.some((entry) => {
    const h = String(entry).toLowerCase().trim();
    return h && (host === h || host.endsWith(`.${h}`));
  });
  if (!ok) throw new Error(`Téléchargement refusé (hôte non autorisé : ${host})`);
  return parsed.toString();
}

/** Vérifie aussi les liens symboliques : un chemin lexicalement sûr ne doit pas sortir via un symlink. */
function assertNoSymlinkEscape(base, target) {
  const root = path.resolve(base);
  const rel = path.relative(root, target);
  let current = root;
  for (const part of rel.split(path.sep).filter(Boolean)) {
    current = path.join(current, part);
    if (!fs.existsSync(current)) continue;
    const real = fs.realpathSync(current);
    if (real !== root && !real.startsWith(root + path.sep)) {
      throw new Error(`Chemin refusé (lien symbolique hors du dossier du jeu) : ${part}`);
    }
  }
}

async function fetchChecked(url, allowedHosts, fetchImpl, maxRedirects = MAX_REDIRECTS) {
  let current = checkUrl(url, allowedHosts);
  for (let i = 0; i <= maxRedirects; i++) {
    const res = await fetchImpl(current, { redirect: 'manual' });
    if (![301, 302, 303, 307, 308].includes(res.status)) return res;
    const location = res.headers && res.headers.get('location');
    if (!location) throw new Error('Redirection de téléchargement invalide.');
    if (i === maxRedirects) throw new Error('Trop de redirections pendant le téléchargement.');
    current = checkUrl(new URL(location, current).toString(), allowedHosts);
  }
  throw new Error('Téléchargement interrompu.');
}

async function sha1Of(file) {
  const hash = crypto.createHash('sha1');
  await pipeline(fs.createReadStream(file), hash);
  return hash.digest('hex');
}

async function download(url, destination, expectedSha1, fetchImpl = fetch, allowedHosts = []) {
  if (!/^[a-f0-9]{40}$/i.test(String(expectedSha1 || ''))) {
    throw new Error(`Empreinte SHA-1 manquante ou invalide : ${path.basename(destination)}`);
  }
  const res = await fetchChecked(url, allowedHosts, fetchImpl);
  if (!res.ok || !res.body) throw new Error(`Téléchargement impossible (HTTP ${res.status}) : ${url}`);
  const declared = Number(res.headers && res.headers.get('content-length'));
  if (Number.isFinite(declared) && declared > MAX_FILE_BYTES) {
    throw new Error(`Fichier trop volumineux (maximum ${Math.round(MAX_FILE_BYTES / 1048576)} Mo).`);
  }
  const tmp = `${destination}.download`;
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  let total = 0;
  const body = Readable.fromWeb(res.body);
  body.on('data', (chunk) => {
    total += chunk.length;
    if (total > MAX_FILE_BYTES) body.destroy(new Error('Fichier trop volumineux.'));
  });
  try {
    await pipeline(body, fs.createWriteStream(tmp, { flags: 'wx' }));
    const actual = await sha1Of(tmp);
    if (actual.toLowerCase() !== String(expectedSha1).toLowerCase()) {
      throw new Error(`Fichier corrompu ou modifié (empreinte différente) : ${path.basename(destination)}`);
    }
    fs.renameSync(tmp, destination);
  } catch (err) {
    fs.rmSync(tmp, { force: true });
    throw err;
  }
}

// ------------------------------------------------------------------
// Synchronisation des mods et fichiers du pack
// ------------------------------------------------------------------

/**
 * Met le dossier du jeu en accord avec le pack : télécharge ce qui manque ou a changé (vérifié par SHA-1),
 * supprime les mods que le pack ne contient plus. Seuls les fichiers installés par le lanceur sont supprimés :
 * les fichiers ajoutés à la main par le joueur ne sont jamais touchés.
 */
async function syncPack(pack, instanceDir, options = {}) {
  const allowedHosts = options.allowedHosts || [];
  const onStatus = options.onStatus || (() => {});
  const fetchImpl = options.fetch || fetch;

  fs.mkdirSync(instanceDir, { recursive: true });
  const manifestFile = path.join(instanceDir, MANIFEST_NAME);
  let previous = { files: [] };
  try {
    previous = JSON.parse(fs.readFileSync(manifestFile, 'utf8'));
  } catch (_) {
    // pas encore de manifeste
  }

  // Liste de tout ce que le pack veut : mods (dans mods/) et fichiers libres
  const wanted = [];
  for (const mod of pack.mods) {
    if (!mod.file || !mod.url) throw new Error('Un mod du pack n\'a pas de "file" ou d\'"url".');
    wanted.push({
      relative: `mods/${mod.file}`,
      url: mod.url,
      sha1: mod.sha1,
      overwrite: true,
      label: mod.name || mod.file,
    });
  }
  for (const f of pack.files) {
    if (!f.path || !f.url) throw new Error('Un fichier du pack n\'a pas de "path" ou d\'"url".');
    wanted.push({ relative: f.path, url: f.url, sha1: f.sha1, overwrite: f.overwrite !== false, label: f.path });
  }

  let done = 0;
  const installed = [];
  for (const item of wanted) {
    const target = safeJoin(instanceDir, item.relative);
    assertNoSymlinkEscape(instanceDir, target);
    const url = checkUrl(item.url, allowedHosts);
    if (!/^[a-f0-9]{40}$/i.test(String(item.sha1 || ''))) {
      throw new Error(`Empreinte SHA-1 manquante ou invalide : ${item.relative}`);
    }
    done += 1;
    const progress = `${done}/${wanted.length}`;

    const exists = fs.existsSync(target);
    if (exists && !item.overwrite) continue; // fichier de départ (ex. options.txt) : jamais écrasé
    if (exists && item.sha1 && (await sha1Of(target)).toLowerCase() === String(item.sha1).toLowerCase()) {
      installed.push(item.relative); // déjà à jour
      continue;
    }
    onStatus(`Téléchargement : ${item.label} (${progress})`);
    await download(url, target, item.sha1, fetchImpl, allowedHosts);
    // Un fichier de départ appartient au joueur dès qu'il existe : on ne le suit pas, donc on ne le supprimera jamais
    if (item.overwrite) installed.push(item.relative);
  }

  // Supprime ce que le lanceur avait installé et que le pack ne contient plus
  let removed = 0;
  for (const old of previous.files || []) {
    if (installed.includes(old)) continue;
    try {
      const target = safeJoin(instanceDir, old);
      assertNoSymlinkEscape(instanceDir, target);
      if (fs.existsSync(target)) {
        fs.rmSync(target, { force: true });
        removed += 1;
      }
    } catch (_) {
      // chemin suspect dans un ancien manifeste : ignoré
    }
  }
  if (removed > 0) onStatus(`${removed} ancien(s) fichier(s) retiré(s)`);

  fs.writeFileSync(manifestFile, JSON.stringify({ packVersion: pack.version, files: installed }, null, 2));
  return { installed: installed.length, removed };
}

module.exports = { validatePack, fetchPack, syncPack, safeJoin, checkUrl, sha1Of, fetchChecked, assertNoSymlinkEscape, MANIFEST_NAME };
