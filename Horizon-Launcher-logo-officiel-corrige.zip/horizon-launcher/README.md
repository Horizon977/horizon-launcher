# Lanceur Horizon SMP

Lanceur Minecraft Java pour ton serveur : le joueur se connecte avec son compte Microsoft, clique sur **JOUER**, et le lanceur
installe tout seul la bonne version de Minecraft, la bonne version de Java, les mods du pack, puis lance le jeu **directement sur
ton serveur**. Il affiche aussi « Joue à Horizon SMP » sur le profil Discord du joueur et se met à jour tout seul.

- Le **lanceur** est publié dans les *Releases* de ton dépôt GitHub (mise à jour automatique).
- Le **pack** (`pack/pack.json` : version de Minecraft, mods, adresse du serveur) est publié sur GitHub Pages. Quand tu le modifies,
  tous les joueurs reçoivent la mise à jour à leur prochain lancement, sans réinstaller le lanceur.

> ⚠️ **Ce code n'a pas pu être essayé en vrai par son auteur** (pas d'écran, pas d'accès aux serveurs de Mojang ni de Microsoft).
> Les parties qui ne dépendent pas d'Internet sont testées (`npm test`) ; le reste doit être vérifié au premier lancement (voir « Premier test »).

## 1. Mise en place (une seule fois)

1. **Crée un dépôt GitHub** (par exemple `horizon-launcher`, public) et envoie-y ce dossier.
2. **Ton pseudo GitHub est déjà renseigné** (`Horizon977`) dans `package.json` (`build.publish[0].owner`) et dans `src/config.json` (`packUrl` :
   `https://horizon977.github.io/horizon-launcher/pack.json`). Cela suppose que ton dépôt s'appelle **`horizon-launcher`** : sinon, remplace ce nom aux deux endroits.
3. **Active GitHub Pages** : dépôt → *Settings* → *Pages* → *Source* : **GitHub Actions**. Le dossier `pack/` est alors publié
   à chaque modification (workflow « Publier le pack »).
4. **Remplis `src/config.json`** :
   - `serverAddress` : l'adresse de ton serveur (ex. `play.horizon-smp.fr`, avec `:port` si ce n'est pas 25565) ; mets la même dans `pack/pack.json` → `server.address`,
   - `discordAppId` : voir « Discord » plus bas,
   - `discordInviteUrl` : ton lien d'invitation Discord (affiche un bouton dans le lanceur).
5. **Vérifie `pack/pack.json`** :
   - `minecraft` doit être l'identifiant **exact** d'une version de Minecraft chez Mojang. `26.3` est une version Java officielle ; vérifie seulement que ton serveur utilise bien cette version.
   - Le pack est en **vanilla** (aucun mod) : c'est le plus sûr pour commencer.

## 2. Premier test (important)

```
npm install
npm test        # doit afficher 21 tests réussis
npm start       # ouvre le lanceur
```

Connecte-toi avec un compte qui possède Minecraft Java, clique sur **JOUER**, et vérifie dans l'ordre : le pack est lu, Minecraft puis Java se
téléchargent, le jeu se lance et arrive sur ton serveur. Si une étape échoue, le message s'affiche dans le lanceur ; envoie-le moi
(le journal du jeu est dans `%APPDATA%/HorizonSMP/logs/`).

## 3. Publier le lanceur aux joueurs

```
git tag v1.0.0
git push origin v1.0.0
```

Le workflow « Publier le lanceur » construit l'installeur Windows (et un AppImage Linux) et les ajoute à la page **Releases**. Donne aux joueurs
le lien de téléchargement de la dernière release. Pour une nouvelle version, change `version` dans `package.json`, puis pousse une nouvelle étiquette
(`v1.0.1`) : les lanceurs installés se mettent à jour tout seuls.

Windows affichera « application inconnue » (SmartScreen) tant que l'installeur n'est pas **signé** (la signature est payante). Prévient tes joueurs :
*Informations complémentaires → Exécuter quand même*.

## 4. Gérer le pack (mods)

Les mods ne sont **pas** copiés dans le dépôt : le pack pointe vers Modrinth, avec une empreinte SHA-1 obligatoire et vérifiée avant chaque installation. Les liens HTTPS sont contrôlés aussi après chaque redirection, les fichiers sont limités à 512 Mo et les chemins contenant des liens symboliques vers l'extérieur sont refusés.

```
npm run pack:list
node tools/pack.js set-loader fabric        # passe le pack en Fabric (dernière version stable)
node tools/pack.js add sodium               # ajoute un mod depuis Modrinth (bonne version du jeu automatiquement)
node tools/pack.js remove sodium
```

Après chaque modification, envoie `pack/pack.json` sur la branche `main` : il est publié automatiquement et les joueurs le reçoivent au prochain lancement.
Le lanceur ne supprime **que** les fichiers qu'il a installés : les mods ajoutés à la main par un joueur sont conservés, et un fichier de départ
(`overwrite: false`, par exemple `options.txt`) n'est jamais écrasé ni supprimé.

Avant de passer en Fabric, vérifie que Fabric et tes mods existent pour ta version de Minecraft : les versions « 26.x » sont récentes.

## 5. Discord : « Joue à Horizon SMP »

1. Va sur <https://discord.com/developers/applications> → *New Application* → nomme-la **Horizon SMP** (ce nom s'affiche sur le profil du joueur).
2. Copie l'**Application ID** dans `src/config.json` → `discordAppId`.
3. *Rich Presence* → *Art Assets* → ajoute ton logo avec le nom exact **`logo`**.

Discord doit être ouvert sur l'ordinateur du joueur ; sinon le lanceur réessaie discrètement toutes les 30 secondes.

## 6. Compte Microsoft : à lire

Le joueur se connecte avec un **code appareil** : il ouvre la page officielle de Microsoft et tape un code. Le lanceur ne voit **jamais** son mot de passe.
Les jetons de connexion sont gardés dans `%APPDATA%/HorizonSMP/auth/` (comme le font les autres lanceurs).

Par défaut, la connexion utilise l'identifiant d'application du lanceur officiel de Minecraft, comme beaucoup de lanceurs libres. Pour un lanceur
public, la voie propre est d'enregistrer **ta propre application** sur Microsoft Azure (gratuit), de demander à Mojang l'autorisation d'utiliser les
services Minecraft avec cet identifiant, puis de le mettre dans `src/config.json` → `"microsoftClientId": "..."`. Tant que Mojang n'a pas validé
ton application, la connexion avec ton propre identifiant sera refusée.

## 7. Limites à connaître

- **Java Edition uniquement.** Les joueurs Bedrock ne passent pas par un lanceur : ils arrivent par Geyser.
- **Comptes Microsoft uniquement.** Ce lanceur n'a pas de mode « compte pirate » ; si ton serveur accepte les comptes non officiels, ces joueurs
  ne peuvent pas l'utiliser.
- Les bibliothèques de téléchargement de Minecraft (`@xmcl/*`) sont figées sur des versions qui s'installent avec npm ; si Mojang change le format de ses
  fichiers, il faudra les mettre à jour.
- Aucun secret n'est stocké dans ce dépôt (il est public) : pas de token de bot, pas de clé.

## Structure

```
pack/pack.json            le pack publié sur GitHub Pages
src/config.json           réglages du lanceur (serveur, adresse du pack, Discord)
src/main/                 le programme : connexion, pack, installation, lancement, Discord
src/renderer/             l'interface
tools/pack.js             outil pour gérer les mods
tests/run.js              tests (npm test)
.github/workflows/        publication automatique (lanceur, pack, tests)
```


## Créer l’installateur Windows

Installe Node.js LTS, puis double-clique sur `CREER_LE_EXE.bat`. Le script installe les dépendances et lance `npm run dist`. L’installateur généré se trouve dans `dist`. Une connexion Internet est nécessaire lors de la première compilation.
