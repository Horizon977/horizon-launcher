@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Creation de Horizon Launcher
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js LTS est requis. Installe-le depuis https://nodejs.org/ puis relance ce fichier.
 pause
 exit /b 1
)
echo [1/2] Installation des dependances...
call npm ci
if errorlevel 1 goto erreur
echo [2/3] Verification des tests...
call npm test
if errorlevel 1 goto erreur
echo [3/3] Compilation de l'installateur Windows...
call npm run dist
if errorlevel 1 goto erreur
echo.
echo Termine ! L'installateur est dans le dossier dist.
explorer "%CD%\dist"
pause
exit /b 0
:erreur
echo.
echo La compilation a echoue. Lis les erreurs ci-dessus.
pause
exit /b 1
