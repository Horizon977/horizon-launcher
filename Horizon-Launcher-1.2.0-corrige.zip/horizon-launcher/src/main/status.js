'use strict';
async function fetchServerStatus(apiBase, address, fetchImpl = fetch) {
  const offline = { online: false, known: false, players: 0, max: 0, version: '' };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const res = await fetchImpl(`${apiBase}${encodeURIComponent(address)}`, { signal: controller.signal, headers: { 'User-Agent': 'HorizonLauncher' } });
    if (!res.ok) return offline;
    const data = await res.json();
    return { known: true, online: !!data.online, players: Number(data.players?.online || 0), max: Number(data.players?.max || 0), version: String(data.version?.name || '') };
  } catch (_) { return offline; }
  finally { clearTimeout(timer); }
}
module.exports = { fetchServerStatus };
