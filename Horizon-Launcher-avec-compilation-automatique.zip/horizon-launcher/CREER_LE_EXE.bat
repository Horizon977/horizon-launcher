@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Creation de Horizon Launcher - Installateur Windows

echo ================================================
echo       CREATION DE HORIZON LAUNCHER (.EXE)
echo ================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERREUR : Node.js n'est pas installe.
  echo Installe la version LTS depuis : https://nodejs.org/
  echo Puis relance ce fichier CREER_LE_EXE.bat.
  echo.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo ERREUR : npm est introuvable. Reinstalle Node.js LTS.
  pause
  exit /b 1
)

echo [1/3] Installation des dependances (cela peut prendre quelques minutes)...
call npm ci
if errorlevel 1 goto erreur

echo.
echo [2/3] Verification des tests...
call npm test
if errorlevel 1 (
  echo.
  echo ATTENTION : les tests ont echoue. La compilation est arretee pour eviter de creer un installateur potentiellement defectueux.
  goto erreur
)

echo.
echo [3/3] Creation de l'installateur Windows...
call npm run dist
if errorlevel 1 goto erreur

echo.
echo ================================================
echo COMPILATION TERMINEE !
echo ================================================
echo Ton installateur se trouve dans le dossier :
echo %CD%\dist\
echo.
explorer "%CD%\dist"
pause
exit /b 0

:erreur
echo.
echo La creation du .exe a echoue. Lis le message ci-dessus pour trouver la cause.
echo Verifie ta connexion Internet et que Node.js LTS est installe.
pause
exit /b 1
