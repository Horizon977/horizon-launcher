# Lanceur Horizon SMP

Lanceur Minecraft Java pour ton serveur : le joueur se connecte avec son compte Microsoft, clique sur **JOUER**, et le lanceur
installe tout seul la bonne version de Minecraft, la bonne version de Java, les mods du pack, puis lance le jeu **directement sur
ton serveur**. Il affiche aussi « Joue à Horizon SMP » sur le profil Discord du joueur et se met à jour tout seul.

- Le **lanceur** est publié dans les *Releases* de ton dépôt GitHub (mise à jour automatique).
- Le **pack** (`pack/pack.json` : version de Minecraft, mods, adresse du serveur) est publié sur GitHub Pages. Quand tu le modifies,
  tous les joueurs reçoivent la mise à jour à leur prochain lancement, sans réinstaller le lanceur.

> ⚠️ Les tests automatisés couvrent les fonctions locales et les téléchargements simulés. La connexion réelle Microsoft, les serveurs Mojang, le statut du serveur et le lancement du jeu doivent encore être validés sur un PC Windows avec un compte Minecraft Java.

## 1. Mise en place (une seule fois)

1. **Crée un dépôt GitHub** (par exemple `horizon-launcher`, public) et envoie-y ce dossier.
2. **Ton pseudo GitHub est déjà renseigné** (`Horizon977`) dans `package.json` (`build.publish[0].owner`) et dans `src/config.json` (`packUrl` :
   `https://horizon977.github.io/horizon-launcher/pack.json`). Cela suppose que ton dépôt s'appelle **`horizon-launcher`** : sinon, remplace ce nom aux deux endroits.
3. **Active GitHub Pages** : dépôt → *Settings* → *Pages* → *Source* : **GitHub Actions**. Le dossier `pack/` est alors publié
   à chaque modification (workflow « Publier le pack »).
4. **Remplis `src/config.json`** :
   - `serverAddress` : l'adresse de ton serveur (ex. `Horizon-KhNu.aternos.me` (Java, port 25565 par défaut)) ; mets la même dans `pack/pack.json` → `server.address`,
   - `discordAppId` : voir « Discord » plus bas,
   - `discordInviteUrl` : ton lien d'invitation Discord (affiche un bouton dans le lanceur).
5. **Vérifie `pack/pack.json`** :
   - `minecraft` doit être l'identifiant **exact** d'une version de Minecraft chez Mojang. `26.3` est une version Java officielle ; vérifie seulement que ton serveur utilise bien cette version.
   - Le pack est en **vanilla** (aucun mod) : c'est le plus sûr pour commencer.

## 2. Premier test (important)

```
npm install
npm test        # lance les tests automatisés
npm start       # ouvre le lanceur
```

Connecte-toi avec un compte qui possède Minecraft Java, clique sur **JOUER**, et vérifie dans l'ordre : le pack est lu, Minecraft puis Java se
téléchargent, le jeu se lance et arrive sur ton serveur. Si une étape échoue, le message s'affiche dans le lanceur ; envoie-le moi
(le journal du jeu est dans `%APPDATA%/HorizonSMP/logs/`).

## 3. Publier le lanceur aux joueurs

```
git tag v1.2.0
git push origin v1.2.0
```

Le workflow « Publier le lanceur » construit l'installeur Windows (et un AppImage Linux) et les ajoute à la page **Releases**. Donne aux joueurs
le lien de téléchargement de la dernière release. Pour une nouvelle version, change `version` dans `package.json`, puis pousse une nouvelle étiquette
(`v1.2.3`) : les lanceurs installés se mettent à jour tout seuls.

Windows affichera « application inconnue » (SmartScreen) tant que l'installeur n'est pas **signé** (la signature est payante). Prévient tes joueurs :
*Informations complémentaires → Exécuter quand même*.

## 4. Gérer le pack (mods)

Les mods ne sont **pas** copiés dans le dépôt : le pack pointe vers Modrinth, avec une empreinte SHA-1 obligatoire et vérifiée avant chaque installation. Les liens HTTPS sont contrôlés aussi après chaque redirection, les fichiers sont limités à 512 Mo et les chemins contenant des liens symboliques vers l'extérieur sont refusés.

```
npm run pack:list
node tools/pack.js set-loader fabric        # passe le pack en Fabric (dernière version stable)
node tools/pack.js add sodium               # ajoute un mod depuis Modrinth (bonne version du jeu automatiquement)
node tools/pack.js remove sodium
```

Après chaque modification, envoie `pack/pack.json` sur la branche `main` : il est publié automatiquement et les joueurs le reçoivent au prochain lancement. Pour activer la maintenance sans reconstruire le launcher, mets `"maintenance": true` et renseigne `maintenanceMessage` dans `pack/pack.json`. Remets `false` pour rouvrir le serveur.
Le lanceur ne supprime **que** les fichiers qu'il a installés : les mods ajoutés à la main par un joueur sont conservés, et un fichier de départ
(`overwrite: false`, par exemple `options.txt`) n'est jamais écrasé ni supprimé.

Avant de passer en Fabric, vérifie que Fabric et tes mods existent pour ta version de Minecraft : les versions « 26.x » sont récentes.

## 5. Discord : « Joue à Horizon SMP »

1. Va sur <https://discord.com/developers/applications> → *New Application* → nomme-la **Horizon SMP** (ce nom s'affiche sur le profil du joueur).
2. Copie l'**Application ID** dans `src/config.json` → `discordAppId`.
3. *Rich Presence* → *Art Assets* → ajoute ton logo avec le nom exact **`logo`**.

Discord doit être ouvert sur l'ordinateur du joueur ; sinon le lanceur réessaie discrètement toutes les 30 secondes.

## 6. Compte Microsoft : à lire

Le joueur se connecte avec un **code appareil** : il ouvre la page officielle de Microsoft et tape un code. Le lanceur ne voit **jamais** son mot de passe.
Les jetons de connexion sont gardés dans `%APPDATA%/HorizonSMP/auth/` (comme le font les autres lanceurs).

La configuration accepte `microsoftClientId` dans `src/config.json`. Laisse cette valeur vide tant que tu n'as pas obtenu un identifiant d'application Microsoft autorisé pour les services Minecraft. Pour une publication publique, enregistre ta propre application et suis la procédure d'autorisation de Mojang/Microsoft. Ne publie jamais de secret ou de jeton dans le dépôt. L'identifiant n'est pas généré automatiquement par le lanceur.

## 7. Limites à connaître

- **Java Edition uniquement.** Les joueurs Bedrock ne passent pas par un lanceur : ils arrivent par Geyser.
- **Comptes Microsoft uniquement.** Ce lanceur n'a pas de mode « compte pirate » ; si ton serveur accepte les comptes non officiels, ces joueurs
  ne peuvent pas l'utiliser.
- Les bibliothèques de téléchargement de Minecraft (`@xmcl/*`) sont figées sur des versions qui s'installent avec npm ; si Mojang change le format de ses
  fichiers, il faudra les mettre à jour.
- Aucun secret n'est stocké dans ce dépôt (il est public) : pas de token de bot, pas de clé.

## Structure

```
pack/pack.json            le pack publié sur GitHub Pages
src/config.json           réglages du lanceur (serveur, adresse du pack, Discord)
src/main/                 le programme : connexion, pack, installation, lancement, Discord
src/renderer/             l'interface
tools/pack.js             outil pour gérer les mods
tests/run.js              tests (npm test)
.github/workflows/        publication automatique (lanceur, pack, tests)
```


## Créer l’installateur Windows

Installe Node.js LTS, puis double-clique sur `CREER_LE_EXE.bat`. Le script installe les dépendances et lance `npm run dist`. L’installateur généré se trouve dans `dist`. Une connexion Internet est nécessaire lors de la première compilation.

## Version 1.2.0 – correctifs

- Adresse Java du serveur configurée sur `Horizon-KhNu.aternos.me` dans le launcher et le pack.
- Version de l'application alignée sur `1.2.0` ; le workflow de release doit être déclenché par le tag `v1.2.0` pour générer les métadonnées `latest.yml` d'Electron Updater.
- Téléchargement du pack avec délai maximal et trois tentatives.
- Téléchargement des fichiers avec progression, vitesse, taille restante lorsqu'elle est annoncée, délai maximal et trois tentatives.
- Affichage de la version serveur quand l'API la fournit.
- Mode maintenance configurable dans `src/config.json` (`maintenance` et `maintenanceMessage`).
- Validation du chemin Java personnalisé par exécution de `java -version`.
- Consultation des journaux Minecraft dans l'interface.
- Rich Presence Discord affiche le pseudo connecté comme état.

**Microsoft :** `microsoftClientId` reste vide par défaut. Il faut renseigner un identifiant d'application réellement autorisé ; aucun identifiant ne peut être inventé ou remplacé automatiquement.


## Publication de la version 1.2.3

La version 1.2.3 fixe le nom de l'installateur Windows utilisé par les mises à jour. Le nom publié est `Horizon-SMP-Setup-1.2.3.exe`. Electron Builder génère `latest.yml` à partir de ce même nom : ne modifie pas le nom de l'asset après la compilation.

Pour publier : pousse les fichiers sur `main`, puis crée et pousse un tag neuf `v1.2.3`. Le tag `v1.2.0` déjà publié ne doit pas être réutilisé.
