'use strict';

const UNKNOWN = { online: false, known: false, players: 0, max: 0, version: '' };

async function readStatus(url, fetchImpl) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 7000);
  try {
    const res = await fetchImpl(url, { signal: controller.signal, headers: { 'User-Agent': 'HorizonLauncher' } });
    if (!res.ok) return null;
    const data = await res.json();
    if (typeof data.online !== 'boolean') return null;
    return {
      online: data.online,
      players: Number(data.players?.online || 0),
      max: Number(data.players?.max || 0),
      version: String(data.version?.name || '')
    };
  } catch (_) {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// Deux services indépendants sont consultés pour éviter un faux « en ligne ».
// En cas de désaccord ou de réponse incomplète, l'interface affiche un état inconnu.
async function fetchServerStatus(apiBase, address, fetchImpl = fetch, secondaryApiBase = 'https://api.mcstatus.io/v2/status/java/') {
  if (!apiBase || !address || !secondaryApiBase) return UNKNOWN;
  const encoded = encodeURIComponent(address);
  const [first, second] = await Promise.all([
    readStatus(`${apiBase}${encoded}`, fetchImpl),
    readStatus(`${secondaryApiBase}${encoded}`, fetchImpl)
  ]);

  if (!first || !second || first.online !== second.online) return UNKNOWN;
  if (!first.online) return { known: true, online: false, players: 0, max: 0, version: '' };

  const version = first.version || second.version;
  // Une réponse « online » sans version ressemble souvent à une réponse proxy/cache
  // et ne suffit pas à afficher un voyant vert.
  if (!version) return UNKNOWN;
  return {
    known: true,
    online: true,
    players: Math.max(first.players, second.players),
    max: Math.max(first.max, second.max),
    version
  };
}

module.exports = { fetchServerStatus };
